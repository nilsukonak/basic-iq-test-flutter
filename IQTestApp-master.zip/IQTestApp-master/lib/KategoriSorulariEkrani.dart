import 'package:flutter/material.dart';
import 'screen/QuizGorsel.dart';
import 'screen/QuizSayisal.dart';
import 'screen/QuizSozel.dart';

class KategoriSorulariEkrani extends StatelessWidget {
  final String kategoriAdi;

  const KategoriSorulariEkrani({required this.kategoriAdi, super.key});
  //kategori sayısı fazla olsaydı map kullanarak daha esnek bir yapı haline getirilebilidi ama burda gerek yok.
  @override
  Widget build(BuildContext context) {
    if (kategoriAdi == "sözel") {
      return QuizSozel(); // Sözel için özel ekran
    } else if (kategoriAdi == "sayısal") {
      return QuizSayisal();
    } else {
      return QuizGorsel();
    }
  }
}

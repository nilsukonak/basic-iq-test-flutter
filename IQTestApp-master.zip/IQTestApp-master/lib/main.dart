import 'package:flutter/material.dart';
import 'package:quizapp/HomePage.dart'; // HomePage yolun buysa

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'IQ Test',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const HomePage(), // sadece HomePage'e yönlendir
    );
  }
}

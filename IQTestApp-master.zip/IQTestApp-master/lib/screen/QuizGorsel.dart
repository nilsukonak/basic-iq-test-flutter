import 'package:flutter/material.dart';
import 'package:quizapp/questions/gorselq.dart';

class QuizGorsel extends StatefulWidget {
  final int sozelScore;
  final int sayisalScore;

  const QuizGorsel({Key? key, this.sozelScore = 0, this.sayisalScore = 0})
    : super(key: key);

  @override
  _QuizGorselState createState() => _QuizGorselState();
}

class _QuizGorselState extends State<QuizGorsel> {
  int currentQuestionIndex = 0;
  int score = 0;

  void _checkAnswer(int selectedIndex) {
    if (selectedIndex == gorselQuestions[currentQuestionIndex].correctIndex) {
      score++;
    }

    setState(() {
      currentQuestionIndex++;
    });
  }

  @override
  Widget build(BuildContext context) {
    // Tüm testler tamamlandığında Genel Değerlendirme Raporu
    if (currentQuestionIndex >= gorselQuestions.length) {
      int totalScore = widget.sozelScore + widget.sayisalScore + score;
      int totalQuestions = 15; // 5 Sözel + 5 Sayısal + 5 Görsel
      int totalWrong = totalQuestions - totalScore;

      return Scaffold(
        appBar: AppBar(
          title: const Text("Genel IQ Değerlendirme"),
          backgroundColor: const Color(0xFF201E43),
          automaticallyImplyLeading: false,
        ),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.emoji_events_rounded,
                  size: 85,
                  color: Colors.amber,
                ),
                const SizedBox(height: 16),
                const Text(
                  "Tüm Testler Tamamlandı!",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 20),
                Card(
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(18.0),
                    child: Column(
                      children: [
                        _buildScoreRow(
                          "Sözel Bölüm",
                          "${widget.sozelScore} / 5",
                        ),
                        const Divider(),
                        _buildScoreRow(
                          "Sayısal Bölüm",
                          "${widget.sayisalScore} / 5",
                        ),
                        const Divider(),
                        _buildScoreRow("Görsel Bölüm", "$score / 5"),
                        const Divider(thickness: 2),
                        _buildScoreRow(
                          "Genel Toplam",
                          "$totalScore / $totalQuestions",
                          isBold: true,
                          valueColor: Colors.blueAccent,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  "Toplam Yanlış: $totalWrong",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.red[700],
                  ),
                ),
                const SizedBox(height: 28),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).popUntil((route) => route.isFirst);
                  },
                  icon: const Icon(Icons.home),
                  label: const Text("Ana Sayfaya Dön"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF201E43),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    GorselQuestion currentQuestion = gorselQuestions[currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Görsel Quiz (${currentQuestionIndex + 1}/${gorselQuestions.length})",
        ),
        backgroundColor: const Color(0xFF201E43),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: Icon(
                currentQuestion.icon,
                size: 100,
                color: const Color(0xFF201E43),
              ),
            ),
            const SizedBox(height: 24),
            for (int i = 0; i < currentQuestion.options.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () => _checkAnswer(i),
                  child: Text(
                    currentQuestion.options[i],
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreRow(
    String label,
    String value, {
    bool isBold = false,
    Color? valueColor,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
              color: valueColor ?? Colors.black87,
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:quizapp/screen/QuizSayisal.dart';
import 'package:quizapp/questions/sozelq.dart';

class QuizSozel extends StatefulWidget {
  @override
  _QuizSozelState createState() => _QuizSozelState();
}

class _QuizSozelState extends State<QuizSozel> {
  int currentQuestionIndex = 0;
  int score = 0;
  bool isLoadingNextQuiz = false;

  void _checkAnswer(int selectedIndex) {
    if (selectedIndex == sozelQuestions[currentQuestionIndex].correctIndex) {
      score++;
    }

    if (currentQuestionIndex + 1 >= sozelQuestions.length) {
      setState(() {
        isLoadingNextQuiz = true;
      });

      Future.delayed(const Duration(seconds: 1), () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => QuizSayisal(sozelScore: score)),
        );
      });
    } else {
      setState(() {
        currentQuestionIndex++;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoadingNextQuiz) {
      return const Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 20),
              Text("Sayısal sorular hazırlanıyor..."),
            ],
          ),
        ),
      );
    }

    SozelQuestion currentQuestion = sozelQuestions[currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Sözel Quiz (${currentQuestionIndex + 1}/${sozelQuestions.length})",
        ),
        backgroundColor: const Color(0xFF201E43),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              currentQuestion.questionText,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            for (int i = 0; i < currentQuestion.options.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () => _checkAnswer(i),
                  child: Text(
                    currentQuestion.options[i],
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

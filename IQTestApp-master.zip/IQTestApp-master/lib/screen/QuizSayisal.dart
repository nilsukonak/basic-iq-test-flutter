import 'package:flutter/material.dart';
import 'package:quizapp/questions/sayisalq.dart';
import 'package:quizapp/screen/QuizGorsel.dart';

class QuizSayisal extends StatefulWidget {
  final int sozelScore;

  const QuizSayisal({Key? key, this.sozelScore = 0}) : super(key: key);

  @override
  _QuizSayisalState createState() => _QuizSayisalState();
}

class _QuizSayisalState extends State<QuizSayisal> {
  int currentQuestionIndex = 0;
  int score = 0;

  void _checkAnswer(int selectedIndex) {
    if (selectedIndex == sayisalQuestions[currentQuestionIndex].correctIndex) {
      score++;
    }

    if (currentQuestionIndex + 1 >= sayisalQuestions.length) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
              QuizGorsel(sozelScore: widget.sozelScore, sayisalScore: score),
        ),
      );
    } else {
      setState(() {
        currentQuestionIndex++;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    SayisalQuestion currentQuestion = sayisalQuestions[currentQuestionIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Sayısal Quiz (${currentQuestionIndex + 1}/${sayisalQuestions.length})",
        ),
        backgroundColor: const Color(0xFF201E43),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              currentQuestion.questionText,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),
            for (int i = 0; i < currentQuestion.options.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10.0),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () => _checkAnswer(i),
                  child: Text(
                    currentQuestion.options[i],
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

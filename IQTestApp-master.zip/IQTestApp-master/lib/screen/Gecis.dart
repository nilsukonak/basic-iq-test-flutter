import 'package:flutter/material.dart';
import 'package:quizapp/screen/QuizSozel.dart';
import 'dart:async';

class Gecis extends StatefulWidget {
  const Gecis({super.key});

  @override
  State<Gecis> createState() => _GecisState();
}

class _GecisState extends State<Gecis> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(seconds: 2), () {
      if (mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => QuizSozel()),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEEEEEE),
      body: Center(
        child: Text(
          "Sözel sorulara geçiliyor...",
          style: TextStyle(
            color: Color(0xFF201E43),
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

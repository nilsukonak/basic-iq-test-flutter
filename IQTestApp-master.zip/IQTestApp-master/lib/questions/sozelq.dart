class SozelQuestion {
  final String questionText;
  final List<String> options;
  final int correctIndex;

  SozelQuestion({
    required this.questionText,
    required this.options,
    required this.correctIndex,
  });
}

final List<SozelQuestion> sozelQuestions = [
  SozelQuestion(
    questionText: 'Türkiye\'nin başkenti neresidir?',
    options: ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Adana'],
    correctIndex: 1,
  ),
  SozelQuestion(
    questionText: '2Türkiye\'nin başkenti neresidir?',
    options: ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Adana'],
    correctIndex: 2,
  ),
  SozelQuestion(
    questionText: '3Türkiye\'nin başkenti neresidir?',
    options: ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Adana'],
    correctIndex: 3,
  ),
  SozelQuestion(
    questionText: '4Türkiye\'nin başkenti neresidir?',
    options: ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Adana'],
    correctIndex: 4,
  ),
  SozelQuestion(
    questionText: 'Türkiye\'nin başkenti neresidir?',
    options: ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Adana'],
    correctIndex: 5,
  ),
  SozelQuestion(
    questionText: 'Türkiye\'nin başkenti neresidir?',
    options: ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Adana'],
    correctIndex: 6,
  ),
  SozelQuestion(
    questionText: '7Türkiye\'nin başkenti neresidir?',
    options: ['İstanbul', 'Ankara', 'İzmir', 'Bursa', 'Adana'],
    correctIndex: 7,
  ),
];

class SayisalQuestion {
  final String questionText;
  final List<String> options;
  final int correctIndex;

  SayisalQuestion({
    required this.questionText,
    required this.options,
    required this.correctIndex,
  });
}

final List<SayisalQuestion> sayisalQuestions = [
  SayisalQuestion(
    questionText: '2 + 2 kaç eder?',
    options: ['3', '4', '5', '6', '7'],
    correctIndex: 1,
  ),
  SayisalQuestion(
    questionText: '2 + 2 kaç eder?',
    options: ['3', '4', '5', '6', '7'],
    correctIndex: 2,
  ),
  SayisalQuestion(
    questionText: '2 + 2 kaç eder?',
    options: ['3', '4', '5', '6', '7'],
    correctIndex: 3,
  ),
  SayisalQuestion(
    questionText: '2 + 2 kaç eder?',
    options: ['3', '4', '5', '6', '7'],
    correctIndex: 4,
  ),
  SayisalQuestion(
    questionText: '2 + 2 kaç eder?',
    options: ['3', '4', '5', '6', '7'],
    correctIndex: 5,
  ),
  SayisalQuestion(
    questionText: '2 + 2 kaç eder?',
    options: ['3', '4', '5', '6', '7'],
    correctIndex: 6,
  ),
  SayisalQuestion(
    questionText: '2 + 2 kaç eder?',
    options: ['3', '4', '5', '6', '7'],
    correctIndex: 7,
  ),
];

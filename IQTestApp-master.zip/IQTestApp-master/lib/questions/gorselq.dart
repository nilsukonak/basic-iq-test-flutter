import 'package:flutter/material.dart';

class GorselQuestion {
  final IconData icon;
  final List<String> options;
  final int correctIndex;

  GorselQuestion({
    required this.icon,
    required this.options,
    required this.correctIndex,
  });
}

final List<GorselQuestion> gorselQuestions = [
  GorselQuestion(
    icon: Icons.square_outlined,
    options: ['Kare', 'Üçgen', 'Daire', 'Yıldız'],
    correctIndex: 0,
  ),
  GorselQuestion(
    icon: Icons.change_history,
    options: ['Kare', 'Üçgen', 'Daire', 'Yıldız'],
    correctIndex: 1,
  ),
  GorselQuestion(
    icon: Icons.circle_outlined,
    options: ['Kare', 'Üçgen', 'Daire', 'Yıldız'],
    correctIndex: 2,
  ),
  GorselQuestion(
    icon: Icons.star_border,
    options: ['Kare', 'Üçgen', 'Daire', 'Yıldız'],
    correctIndex: 3,
  ),
  GorselQuestion(
    icon: Icons.hexagon_outlined,
    options: ['Altıgen', 'Kare', 'Daire', 'Üçgen'],
    correctIndex: 0,
  ),
];

import 'package:flutter/material.dart';
import 'package:quizapp/screen/Gecis.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFEEEEEE),
      appBar: AppBar(
        backgroundColor: Color(0xFF201E43),
        title: Text("IQ TEST"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Doğrudan Gecis widget'ına yönlendiriyoruz
            Navigator.push(
              context,
              MaterialPageRoute(
                builder:
                    (context) => Gecis(), // Kategori parametresi geçmiyoruz
              ),
            );
          },
          child: Text("Teste Başla"),
        ),
      ),
    );
  }
}
